package smithavenkatesh.asynctask.cmpe277.com.thsensordriver;

public class WrapperTHSensor {
    String[] temp=null,humidity=null,activity=null;
    int sensor_no;

}
